"""Trade performance statistics for quantitative trading systems.

This package provides deterministic, dependency-free functions for
evaluating a sequence of realized trade profit/loss (P&L) values, per
Engineering Manual v1.1.

Renamed from `statistics` to `trade_stats` to avoid shadowing Python's
standard-library `statistics` module.

Public API:
    win_rate: Fraction of trades that were winners.
    loss_rate: Fraction of trades that were losers.
    average_win: Mean P&L of winning trades.
    average_loss: Mean P&L of losing trades (signed, non-positive).
    profit_factor: Ratio of gross profit to gross loss.
    expectancy: Expected P&L per trade.
    average_r_multiple: Mean R-multiple across a sequence of trades.
"""

from .average_loss import average_loss
from .average_r_multiple import average_r_multiple
from .average_win import average_win
from .expectancy import expectancy
from .loss_rate import loss_rate
from .profit_factor import profit_factor
from .win_rate import win_rate

__all__ = [
    "win_rate",
    "loss_rate",
    "average_win",
    "average_loss",
    "profit_factor",
    "expectancy",
    "average_r_multiple",
]

# Semantic versioning per Engineering Manual §25.
# 2.0.0: renamed package from `statistics` to `trade_stats` (breaking
# import-path change for existing callers) and added Research
# Standards / Deterministic Research Rules documentation -> Major bump.
# 2.1.0: added logging (Engineering Manual §14), sourced the epsilon
# tolerance from config/constants.py (§7), switched breakeven
# classification to math.isclose() (§11), and expanded the test suite
# with property/regression/tolerance/cross-validation/performance
# tests (§15) -> Minor bump: no public function signature, return
# value, or import path changed.
__version__ = "2.1.0"
